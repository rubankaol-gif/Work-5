const http = require('http');

const port = process.argv[2];

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/json-object') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      try {
        const data = JSON.parse(body);

        if (typeof data.name !== 'string') {
          sendJson(res, 422, { error: 'Missing name' });
          return;
        }

        if (typeof data.age !== 'number') {
          sendJson(res, 422, { error: 'Missing or invalid age' });
          return;
        }

        sendJson(res, 200, {
          greeting: `Hello ${data.name}`,
          isAdult: data.age >= 18
        });
      } catch (error) {
        sendJson(res, 400, { error: 'Invalid JSON' });
      }
    });

    return;
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(port);
