const http = require('http');

const port = process.argv[2];

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/json-calc') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      try {
        const data = JSON.parse(body);

        if (
          typeof data.a !== 'number' ||
          typeof data.b !== 'number' ||
          typeof data.operation !== 'string'
        ) {
          sendJson(res, 422, { error: 'Missing fields' });
          return;
        }

        let result;

        if (data.operation === 'add') {
          result = data.a + data.b;
        } else if (data.operation === 'subtract') {
          result = data.a - data.b;
        } else if (data.operation === 'multiply') {
          result = data.a * data.b;
        } else if (data.operation === 'divide') {
          if (data.b === 0) {
            sendJson(res, 400, { error: 'Division by zero' });
            return;
          }

          result = data.a / data.b;
        } else {
          sendJson(res, 400, { error: 'Invalid operation' });
          return;
        }

        sendJson(res, 200, { result });
      } catch (error) {
        sendJson(res, 400, { error: 'Invalid JSON' });
      }
    });

    return;
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(port);
