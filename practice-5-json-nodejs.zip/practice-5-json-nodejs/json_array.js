const http = require('http');

const port = process.argv[2];

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/json-array') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      try {
        const data = JSON.parse(body);

        if (!Array.isArray(data.numbers)) {
          sendJson(res, 422, { error: 'Invalid numbers' });
          return;
        }

        const hasInvalidValue = data.numbers.some((item) => typeof item !== 'number');

        if (hasInvalidValue) {
          sendJson(res, 422, { error: 'Invalid numbers' });
          return;
        }

        const count = data.numbers.length;
        const sum = data.numbers.reduce((total, number) => total + number, 0);
        const average = count === 0 ? 0 : sum / count;

        sendJson(res, 200, {
          count,
          sum,
          average
        });
      } catch (error) {
        sendJson(res, 400, { error: 'Invalid JSON' });
      }
    });

    return;
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(port);
