const http = require('http');

const port = process.argv[2];

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/json-echo') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      if (!body) {
        sendJson(res, 400, { error: 'Invalid JSON' });
        return;
      }

      try {
        const data = JSON.parse(body);
        sendJson(res, 200, data);
      } catch (error) {
        sendJson(res, 400, { error: 'Invalid JSON' });
      }
    });

    return;
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(port);
