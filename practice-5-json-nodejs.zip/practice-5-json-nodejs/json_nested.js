const http = require('http');

const port = process.argv[2];

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/json-nested') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      try {
        const data = JSON.parse(body);

        if (!data.user || typeof data.user !== 'object' || Array.isArray(data.user)) {
          sendJson(res, 422, { error: 'Missing user' });
          return;
        }

        if (typeof data.user.name !== 'string') {
          sendJson(res, 422, { error: 'Missing name' });
          return;
        }

        if (!Array.isArray(data.user.roles)) {
          sendJson(res, 422, { error: 'Missing or invalid roles' });
          return;
        }

        sendJson(res, 200, {
          name: data.user.name,
          roleCount: data.user.roles.length,
          isAdmin: data.user.roles.includes('admin')
        });
      } catch (error) {
        sendJson(res, 400, { error: 'Invalid JSON' });
      }
    });

    return;
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(port);
