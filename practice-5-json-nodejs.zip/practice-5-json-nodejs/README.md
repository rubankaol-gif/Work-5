# Practice 5 - JSON Processing / Manual HTTP Router

Готові файли для вправ 5.1–5.5 з модуля `eu-node-basics-workshop`.

## Запуск навчального модуля

Рекомендований варіант без глобальної інсталяції:

```bash
npx eu-node-basics-workshop
```

Альтернативний варіант:

```bash
npm i -g eu-node-basics-workshop
eu-node-basics
```

## Виконані вправи

- 5.1 JSON ECHO — `json_echo.js`
- 5.2 JSON OBJECT — `json_object.js`
- 5.3 JSON ARRAY — `json_array.js`
- 5.4 JSON CALC — `json_calc.js`
- 5.5 JSON NESTED — `json_nested.js`

## Перевірка

```bash
eu-node-basics verify 6 json_echo.js
eu-node-basics verify 7 json_object.js
eu-node-basics verify 8 json_array.js
eu-node-basics verify 9 json_calc.js
eu-node-basics verify 10 json_nested.js
```

## Ручний запуск

Приклад:

```bash
node json_nested.js 3000
```

Після запуску можна перевіряти запити через `curl`, Postman або браузер, якщо це GET-запит.

## Приклад для 5.5 JSON NESTED

```bash
curl -i -X POST "http://127.0.0.1:3000/json-nested" -H "Content-Type: application/json" -d "{\"user\":{\"name\":\"John\",\"roles\":[\"admin\",\"editor\"]}}"
```

Очікувана відповідь:

```json
{"name":"John","roleCount":2,"isAdmin":true}
```

## Публікація результатів

Для здачі роботи потрібно створити GitHub-репозиторій, додати ці файли та README, а також прикріпити скріншот з інтерактивного меню, де вправи мають статус `[COMPLETED]`.
